import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PharmacyManagementSystem {
    private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/pharmacy_management";
        String user = "root";
        String password = "yourpassword";
        return DriverManager.getConnection(url, user, password);
    }

    public void addCustomer(String name, String contact) throws SQLException {
        String query = "INSERT INTO customers (name, contact) VALUES (?, ?)";
        try (Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, name);
            statement.setString(2, contact);
            statement.executeUpdate();
        }
    }

    public Customer getCustomer(int customerId) throws SQLException {
        String query = "SELECT * FROM customers WHERE customer_id = ?";
        try (Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, customerId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                String name = resultSet.getString("name");
                String contact = resultSet.getString("contact");
                return new Customer(customerId, name, contact);
            }
        }
        return null;
    }

    public List<Customer> viewAllCustomers() throws SQLException {
        List<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM customers";
        try (Connection connection = getConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int id = resultSet.getInt("customer_id");
                String name = resultSet.getString("name");
                String contact = resultSet.getString("contact");
                customers.add(new Customer(id, name, contact));
            }
        }
        return customers;
    }

    public void addDrug(Drug drug) throws SQLException {
        String query = "INSERT INTO drugs (name, description, price, stock_quantity) VALUES (?, ?, ?, ?)";
        try (Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, drug.getName());
            statement.setString(2, drug.getDescription());
            statement.setDouble(3, drug.getPrice());
            statement.setInt(4, drug.getStockQuantity());
            statement.executeUpdate();
        }
    }

    public Drug searchDrug(String drugName) throws SQLException {
        String query = "SELECT * FROM drugs WHERE name = ?";
        try (Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, drugName);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int id = resultSet.getInt("drug_id");
                String description = resultSet.getString("description");
                double price = resultSet.getDouble("price");
                int stockQuantity = resultSet.getInt("stock_quantity");
                return new Drug(id, drugName, description, price, stockQuantity);
            }
        }
        return null;
    }

    public List<Drug> viewAllDrugs() throws SQLException {
        List<Drug> drugs = new ArrayList<>();
        String query = "SELECT * FROM drugs";
        try (Connection connection = getConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int id = resultSet.getInt("drug_id");
                String name = resultSet.getString("name");
                String description = resultSet.getString("description");
                double price = resultSet.getDouble("price");
                int stockQuantity = resultSet.getInt("stock_quantity");
                drugs.add(new Drug(id, name, description, price, stockQuantity));
            }
        }
        return drugs;
    }

    public void addSupplier(String name, String contact, String location, int drugId, int stockQuantity)
            throws SQLException {
        Connection connection = null;
        try {
            connection = getConnection();
            connection.setAutoCommit(false);

            String supplierQuery = "INSERT INTO suppliers (name, contact, location) VALUES (?, ?, ?)";
            try (PreparedStatement supplierStmt = connection.prepareStatement(supplierQuery,
                    Statement.RETURN_GENERATED_KEYS)) {
                supplierStmt.setString(1, name);
                supplierStmt.setString(2, contact);
                supplierStmt.setString(3, location);
                supplierStmt.executeUpdate();
                ResultSet rs = supplierStmt.getGeneratedKeys();
                if (rs.next()) {
                    int supplierId = rs.getInt(1);
                    String drugSupplierQuery = "INSERT INTO drug_supplier (supplier_id, drug_id, stock_quantity) VALUES (?, ?, ?)";
                    try (PreparedStatement drugSupplierStmt = connection.prepareStatement(drugSupplierQuery)) {
                        drugSupplierStmt.setInt(1, supplierId);
                        drugSupplierStmt.setInt(2, drugId);
                        drugSupplierStmt.setInt(3, stockQuantity);
                        drugSupplierStmt.executeUpdate();
                    }
                }
            }
            connection.commit();
        } catch (SQLException e) {
            if (connection != null) {
                connection.rollback();
            }
            throw e;
        } finally {
            if (connection != null) {
                connection.setAutoCommit(true);
                connection.close();
            }
        }
    }

    public void addSale(int customerId, int drugId, int quantity) throws SQLException {
        String priceQuery = "SELECT price FROM drugs WHERE drug_id = ?";
        String saleQuery = "INSERT INTO sales (customer_id, drug_id, quantity, sale_date, total_amount) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = getConnection();
                PreparedStatement priceStmt = connection.prepareStatement(priceQuery);
                PreparedStatement saleStmt = connection.prepareStatement(saleQuery)) {

            priceStmt.setInt(1, drugId);
            ResultSet priceResultSet = priceStmt.executeQuery();
            if (priceResultSet.next()) {
                double price = priceResultSet.getDouble("price");
                double totalAmount = price * quantity;

                saleStmt.setInt(1, customerId);
                saleStmt.setInt(2, drugId);
                saleStmt.setInt(3, quantity);
                saleStmt.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
                saleStmt.setDouble(5, totalAmount);
                saleStmt.executeUpdate();
            }
        }
    }

    public List<Purchase> viewPurchaseHistory(int customerId) throws SQLException {
        List<Purchase> purchases = new ArrayList<>();
        String query = "SELECT * FROM sales WHERE customer_id = ? ORDER BY sale_date";
        try (Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, customerId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int purchaseId = resultSet.getInt("sale_id");
                int drugId = resultSet.getInt("drug_id");
                int quantity = resultSet.getInt("quantity");
                LocalDateTime purchaseDate = resultSet.getTimestamp("sale_date").toLocalDateTime();
                double totalAmount = resultSet.getDouble("total_amount");
                purchases.add(new Purchase(purchaseId, customerId, drugId, quantity, purchaseDate, totalAmount));
            }
        }
        return purchases;
    }
}
