import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        PharmacyManagementSystem pharmacyManagementSystem = new PharmacyManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add Customer");
            System.out.println("2. View Purchase History");
            System.out.println("3. Add Drug");
            System.out.println("4. View All Drugs");
            System.out.println("5. Add Sale");
            System.out.println("6. Add Supplier");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            switch (choice) {
                case 1:
                    System.out.print("Enter customer name: ");
                    String customerName = scanner.nextLine();
                    System.out.print("Enter customer contact: ");
                    String customerContact = scanner.nextLine();
                    try {
                        pharmacyManagementSystem.addCustomer(customerName, customerContact);
                        System.out.println("Customer added successfully.");
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    break;

                case 2:
                    System.out.print("Enter customer ID: ");
                    int customerId = scanner.nextInt();
                    try {
                        List<Purchase> purchases = pharmacyManagementSystem.viewPurchaseHistory(customerId);
                        if (purchases.isEmpty()) {
                            System.out.println("No purchase history found.");
                        } else {
                            for (Purchase purchase : purchases) {
                                System.out.println("Purchase ID: " + purchase.getPurchaseId());
                                System.out.println("Drug ID: " + purchase.getDrugId());
                                System.out.println("Quantity: " + purchase.getQuantity());
                                System.out.println("Purchase Date: " + purchase.getPurchaseDate());
                                System.out.println("Total Amount: " + purchase.getTotalAmount());
                                System.out.println();
                            }
                        }
                    } catch (SQLException e) {
                        System.out.println("Error retrieving purchase history: " + e.getMessage());
                    }
                    break;

                case 3:
                    System.out.print("Enter drug name: ");
                    String drugName = scanner.nextLine();
                    System.out.print("Enter drug description: ");
                    String drugDescription = scanner.nextLine();
                    System.out.print("Enter drug price: ");
                    double drugPrice = scanner.nextDouble();
                    System.out.print("Enter drug stock quantity: ");
                    int drugStockQuantity = scanner.nextInt();
                    try {
                        pharmacyManagementSystem
                                .addDrug(new Drug(drugName, drugDescription, drugPrice, drugStockQuantity));
                        System.out.println("Drug added successfully.");
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    break;

                case 4:
                    try {
                        List<Drug> drugs = pharmacyManagementSystem.viewAllDrugs();
                        if (drugs.isEmpty()) {
                            System.out.println("No drugs found.");
                        } else {
                            for (Drug drug : drugs) {
                                System.out.println(drug.toString());
                            }
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    break;

                case 5:
                    System.out.print("Enter customer ID: ");
                    int saleCustomerId = scanner.nextInt();
                    System.out.print("Enter drug ID: ");
                    int saleDrugId = scanner.nextInt();
                    System.out.print("Enter quantity: ");
                    int saleQuantity = scanner.nextInt();
                    try {
                        pharmacyManagementSystem.addSale(saleCustomerId, saleDrugId, saleQuantity);
                        System.out.println("Sale recorded successfully.");
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    break;

                case 6:
                    System.out.print("Enter supplier name: ");
                    String supplierName = scanner.nextLine();
                    System.out.print("Enter supplier contact: ");
                    String supplierContact = scanner.nextLine();
                    System.out.print("Enter supplier location: ");
                    String supplierLocation = scanner.nextLine();
                    System.out.print("Enter drug ID: ");
                    int supplierDrugId = scanner.nextInt();
                    System.out.print("Enter stock quantity supplied: ");
                    int supplierStockQuantity = scanner.nextInt();
                    try {
                        pharmacyManagementSystem.addSupplier(supplierName, supplierContact, supplierLocation,
                                supplierDrugId, supplierStockQuantity);
                        System.out.println("Supplier added successfully.");
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    break;

                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
