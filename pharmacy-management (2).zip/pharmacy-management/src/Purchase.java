import java.time.LocalDateTime;

public class Purchase {
    private int purchaseId;
    private int customerId;
    private int drugId;
    private int quantity;
    private LocalDateTime purchaseDate;
    private double totalAmount;

    public Purchase(int purchaseId, int customerId, int drugId, int quantity, LocalDateTime purchaseDate,
            double totalAmount) {
        this.purchaseId = purchaseId;
        this.customerId = customerId;
        this.drugId = drugId;
        this.quantity = quantity;
        this.purchaseDate = purchaseDate;
        this.totalAmount = totalAmount;
    }

    // Getters and setters

    public int getPurchaseId() {
        return purchaseId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getDrugId() {
        return drugId;
    }

    public int getQuantity() {
        return quantity;
    }

    public LocalDateTime getPurchaseDate() {
        return purchaseDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }
}
