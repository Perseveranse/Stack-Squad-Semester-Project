public class Drug {
    private int drugId;
    private String name;
    private String description;
    private double price;
    private int stockQuantity;

    // Constructor without drugId for new drugs
    public Drug(String name, String description, double price, int stockQuantity) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.stockQuantity = stockQuantity;
    }

    // Constructor with drugId for existing drugs
    public Drug(int drugId, String name, String description, double price, int stockQuantity) {
        this.drugId = drugId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.stockQuantity = stockQuantity;
    }

    // Getters and setters
    public int getDrugId() {
        return drugId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    // Override toString() method
    @Override
    public String toString() {
        return "Drug ID: " + drugId + ", Name: " + name + ", Description: " + description + ", Price: " + price
                + ", Stock Quantity: " + stockQuantity;
    }
}
