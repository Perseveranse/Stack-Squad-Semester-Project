public class Supplier {
    private int supplierId;
    private String name;
    private String contact;
    private String location;

    public Supplier(int supplierId, String name, String contact, String location) {
        this.supplierId = supplierId;
        this.name = name;
        this.contact = contact;
        this.location = location;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public String getName() {
        return name;
    }

    public String getContact() {
        return contact;
    }

    public String getLocation() {
        return location;
    }
}
